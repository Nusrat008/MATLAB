function [ f ] = func_1( x )

f =x^2-5*x+6;

end

