n  = input('Enter a number');

switch n
    case 1 
        disp('The number is positive ');
    case 0
        disp('The number is zero');
    case -1 
        disp('The number is negative');
    otherwise
        disp('I dont know');
        
end