marks = input('Please enter your marks')

if marks >=90
    Grade = string ('A+')
elseif marks >= 80 && marks<90
    Grade = string('A')
elseif marks>=70 && marks<80
    Grade = string('B')
 elseif marks>=60 && marks<70
    Grade = string('C')
else
    Grade = string('F')
end
    
    