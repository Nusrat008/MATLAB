syms x


f = cos(x) + sin(x)

df = diff(f,4)
