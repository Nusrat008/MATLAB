n = input('string')
m = input('Mass(kg): ')

name = input('Enter your name: ','s')
value = 390;
disp(value)
velocity =90.29;
fprintf('the velocity is %.4f m/s \n',velocity)

input('The num is: ')
