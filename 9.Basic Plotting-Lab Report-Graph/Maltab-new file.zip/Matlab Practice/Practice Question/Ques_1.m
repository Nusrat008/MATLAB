
for i = 1:2:9
      for j = 1:i
      fprintf('*')
      end
     fprintf('\n');  
end

for i = 9:-2:1
      for j = 1:i
      fprintf('*')
      end
      
      fprintf('\n');    
end

    