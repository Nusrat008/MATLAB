clear all;
N=300; %max iteration
tol = le-5;
%f = cos(x) - x
% df - -sin(x) - 1
p0 = pi / 4;
i = 0;
while i<=n
    f = cos(p0) - p0;
    df = -sin(p0) - 1;
    if(df==0)
       disp('Zero Derivation');
    end
    
end