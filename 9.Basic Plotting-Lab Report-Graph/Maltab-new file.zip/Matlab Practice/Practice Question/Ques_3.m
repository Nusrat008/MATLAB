fprintf('%5d %10.3f %8.5e\n',100,2*pi,pi);

function fprintfdemo
x = [1 2 3 4 5];
