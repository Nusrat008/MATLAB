function [ f ] = fun( x )
f=x.^3+4*x^2-10;

end

