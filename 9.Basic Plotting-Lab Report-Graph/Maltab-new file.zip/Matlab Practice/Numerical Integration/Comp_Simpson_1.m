clear all;

N = 101;