function [f] =fun( x )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
f= ((1.975308*10^-5)+((.6*10^-6*x)-(2/x)^2))^0.5-0.01

end

