clear all;clc;

x= linspace(0,6,700);
y =x.^2-5*x+6;
plot(x,y)
grid on

