for i = 1:2:30
    disp(i)
end

for i=[5 2 42 34]
    disp(i)
    
    
   
end