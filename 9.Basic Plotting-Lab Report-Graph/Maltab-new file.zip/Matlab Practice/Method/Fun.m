function [ f ] = Fun(x)

%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
f = x.^3 + 4*x^2 - 10;

end

