subplot(1,2,1);plot(sin(t),cos(t))
