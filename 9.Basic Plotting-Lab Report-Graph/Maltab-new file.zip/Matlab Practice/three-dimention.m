t= 0:pi/50:10*pi;
subplot(1,2,1);plot(sin(t),cos(t))
