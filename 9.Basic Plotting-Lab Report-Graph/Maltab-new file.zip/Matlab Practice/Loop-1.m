for i=1:2:10
    disp(i)
    
    
end