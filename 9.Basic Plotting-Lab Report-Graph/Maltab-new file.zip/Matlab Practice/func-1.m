function [ f ] = func-1( x )

f =x^2-5*x+6;

end

