a=5;
b=5;

if a<b
    disp('a<b')
elseif a==b
    disp('a=b')
else 
    disp('a<b')
end

