for i= 1:5
    i
    for j=1:5
        j
        
    end
end